#PDF와 XML 파일이 다른 폴더에 따로 저장되어 있는 경우


import os
import csv
from xml.etree import ElementTree as ET
import shutil
import tempfile


def extract_information_from_xml(xml_file):
    tree = ET.parse(xml_file)
    root = tree.getroot()

    namespaces = {
        'pat': 'http://www.wipo.int/standards/XMLSchema/Patent/1',
        'com': 'http://www.wipo.int/standards/XMLSchema/Common/1',
        'rupat': 'urn:ru:rupto:patent',
    }

    IPOfficeCode_element = root.find('.//com:IPOfficeCode', namespaces=namespaces)
    IPOfficeCode = IPOfficeCode_element.text if IPOfficeCode_element is not None else ''

    PatentNumber_element = root.find('.//pat:PatentNumber', namespaces=namespaces)
    PatentNumber = PatentNumber_element.text if PatentNumber_element is not None else ''

    PatentDocumentKindCode_element = root.find('.//com:PatentDocumentKindCode', namespaces=namespaces)
    PatentDocumentKindCode = PatentDocumentKindCode_element.text if PatentDocumentKindCode_element is not None else ''

    InventionTitle_element = root.find('.//pat:InventionTitle[@com:languageCode="ru"]', namespaces=namespaces)
    InventionTitle = InventionTitle_element.text if InventionTitle_element is not None else ''

    InventionTitle_EN_element = root.find('.//pat:InventionTitle[@com:languageCode="en"]', namespaces=namespaces)
    InventionTitle_EN = InventionTitle_EN_element.text if InventionTitle_EN_element is not None else ''

    Assignee_element = root.find('.//pat:Assignee', namespaces=namespaces)
    if Assignee_element is not None:
        proprietor_name_element = Assignee_element.find('.//pat:OrganizationStandardName', namespaces=namespaces)
        proprietor_name = proprietor_name_element.text if proprietor_name_element is not None else ''
    else:
        proprietor_name = ''

    AbstractRU_elements = root.findall('.//pat:Abstract[@com:languageCode="ru"]/pat:P', namespaces=namespaces)
    abstract_RU = ' '.join([abstract_element.text.strip() for abstract_element in AbstractRU_elements])

    AbstractEN_elements = root.findall('.//pat:Abstract[@com:languageCode="en"]/pat:P', namespaces=namespaces)
    abstract_EN = ' '.join([abstract_element.text.strip() for abstract_element in AbstractEN_elements])

    IPCR_elements = root.findall('.//pat:IPCRClassification', namespaces=namespaces)
    ipcr_list = []
    for ipcr_element in IPCR_elements:
        section = ipcr_element.find('.//pat:Section', namespaces=namespaces).text.strip()
        _class = ipcr_element.find('.//pat:Class', namespaces=namespaces).text.strip()
        subclass = ipcr_element.find('.//pat:SubClass', namespaces=namespaces).text.strip()
        maingroup = ipcr_element.find('.//pat:MainGroup', namespaces=namespaces).text.strip()
        subgroup = ipcr_element.find('.//pat:SubGroup', namespaces=namespaces).text.strip()
        ipcr = f'{section}{_class}{subclass} {maingroup}/{subgroup}'

        # Extract SchemeDate from each IPCRClassification element (if available)
        scheme_date_element = ipcr_element.find('.//pat:PatentClassificationScheme/pat:SchemeDate',
                                                namespaces=namespaces)
        scheme_date = scheme_date_element.text.strip() if scheme_date_element is not None else ''
        a, b = scheme_date.split('-')[0], scheme_date.split('-')[1]

        # Combine SchemeDate with IPCR information
        ipcr_combined = f'{ipcr} ({a}.{b})' if scheme_date else ipcr
        ipcr_list.append(ipcr_combined)

    ipcr_combined = '; '.join(ipcr_list)

    CPC_elements = root.findall('.//rupat:CPCClassification', namespaces=namespaces)
    cpc_list = []
    for cpc_element in CPC_elements:
        section = cpc_element.find('.//rupat:CPCSection', namespaces=namespaces).text.strip()
        _class = cpc_element.find('.//rupat:Class', namespaces=namespaces).text.strip()
        subclass = cpc_element.find('.//rupat:Subclass', namespaces=namespaces).text.strip()
        maingroup = cpc_element.find('.//rupat:MainGroup', namespaces=namespaces).text.strip()
        subgroup = cpc_element.find('.//rupat:Subgroup', namespaces=namespaces).text.strip()
        cpc = f'{section}{_class}{subclass} {maingroup}/{subgroup}'

        # Extract SchemeDate from each CPCClassification element (if available)
        scheme_date_element = cpc_element.find('.//rupat:ClassificationVersionDate', namespaces=namespaces)
        scheme_date = scheme_date_element.text.strip() if scheme_date_element is not None else ''
        a, b = scheme_date.split('-')[0], scheme_date.split('-')[1]

        # Combine SchemeDate with CPC information
        cpc_combined = f'{cpc} ({a}.{b})' if scheme_date else cpc
        cpc_list.append(cpc_combined)

    cpc_combined = '; '.join(cpc_list)

    patent_number = IPOfficeCode + PatentNumber + PatentDocumentKindCode
    return abstract_RU, abstract_EN, InventionTitle, patent_number, proprietor_name, InventionTitle_EN, ipcr_combined, cpc_combined


def rename_files_in_image_folder(image_folder, patent_number):
    if not os.path.exists(image_folder):
        return

    # Iterate over the files in the temporary directory and move them to the "image" folder
    for idx, filename in enumerate(os.listdir(image_folder)):
        ext = os.path.splitext(filename)[1]
        new_filename = f"{patent_number}-{idx + 1}{ext}"
        old_filepath = os.path.join(image_folder, filename)
        new_filepath = os.path.join(image_folder, new_filename)

        # Rename the file
        os.rename(old_filepath, new_filepath)
        print(f"Renamed: {filename} -> {new_filename}")



def process_folder(folder_path, csv_writer, csv_info_writer):
    for root, dirs, files in os.walk(folder_path):
        # Create the 'image' directory if it doesn't exist
        image_destination_path = os.path.join(folder_path, "image")
        if not os.path.exists(image_destination_path):
            os.makedirs(image_destination_path)
        global k
        k = None
        for file in files:
            if file.endswith('.xml'):
                xml_file_path = os.path.join(root, file)
                # Extract information from XML file
                abstract_RU, abstract_EN, doc_name, data, proprietor_name, doc_name_EN, ipcr_combined, cpc_combined = extract_information_from_xml(xml_file_path)
                k = data
                # Check if any information is missing and add to the separate CSV file
                if k is None or not doc_name or not (ipcr_combined or cpc_combined):
                    missing_elements = []
                    if k is None:
                        missing_elements.append('patent_number')
                    if not doc_name:
                        missing_elements.append('doc_name')
                    if not ipcr_combined:
                        missing_elements.append('ipcr')
                    if not cpc_combined:
                        missing_elements.append('cpc')

                    csv_info_writer.writerow([data, xml_file_path, ', '.join(missing_elements)])
                try:
                    # Create the PDF file path by replacing 'XML' with 'PDF'
                    pdf_path_elements = root.split(os.sep)
                    pdf_path_elements[pdf_path_elements.index('XML')] = 'PDF'
                    pdf_root_path = os.sep.join(pdf_path_elements[:])

                    # Find the PDF files in the corresponding PDF path
                    pdf_files = [f for f in os.listdir(pdf_root_path) if f.endswith('.pdf')]
                    if not pdf_files:
                        print(f"No PDF files found in path: {pdf_root_path}. Skipping...")
                        continue

                    # Create a temporary directory to store the PDF files
                    temp_pdf_dir = tempfile.mkdtemp()

                    # Copy PDF files to the temporary directory and rename them
                    for idx, pdf_file in enumerate(pdf_files):
                        pdf_file_path = os.path.join(pdf_root_path, pdf_file)
                        pdf_destination_file_path = os.path.join(temp_pdf_dir, f"{data}-{idx+1}.pdf")
                        shutil.copy(pdf_file_path, pdf_destination_file_path)

                    # Move the renamed PDF files to the final destination
                    pdf_destination_path = os.path.join(folder_path, "output", "PDF")
                    if not os.path.exists(pdf_destination_path):
                        os.makedirs(pdf_destination_path)

                    for pdf_file in os.listdir(temp_pdf_dir):
                        pdf_temp_file_path = os.path.join(temp_pdf_dir, pdf_file)
                        shutil.move(pdf_temp_file_path, pdf_destination_path)

                except:
                    continue


                csv_writer.writerow([data, doc_name_EN, doc_name, proprietor_name, abstract_EN, abstract_RU, ipcr_combined, cpc_combined])
        for file in files:
            if not file.endswith('.xml'):

                xml_file_path = os.path.join(root, file)

                file_path = os.path.join(root, file)

                # Extract patent number from the XML file name
                xml_file_name = [f for f in os.listdir(root) if f.endswith('.xml')]
                if not xml_file_name:
                    continue

                patent_number = k

                file_extension = os.path.splitext(file)[1]
                image_destination_file_path = os.path.join(
                    image_destination_path, f"{patent_number}{file_extension}")

                # If the destination file already exists, add a suffix
                suffix = 1
                while os.path.exists(image_destination_file_path):
                    image_destination_file_path = os.path.join(
                        image_destination_path, f"{patent_number}-{suffix}{file_extension}")
                    suffix += 1

                # Copy the file and rename it
                shutil.copy(file_path, image_destination_file_path)




def extract_information_and_save_to_csv(root_folder, output_csv):
    with open(output_csv, 'w', newline='', encoding='utf-8-sig') as file, open(os.path.join(root_folder, 'missing_list.csv'), 'w', newline='', encoding='utf-8-sig') as csv_info_file:
        writer = csv.writer(file)
        csv_info_writer = csv.writer(csv_info_file)

        writer.writerow(
            ['patent_number', 'doc_name_EN', 'doc_name', 'proprietor_name', 'abstract_EN', 'abstract_RU', 'IPCR', 'CPC'])
        csv_info_writer.writerow(['patent_number', 'directory'])

        process_folder(root_folder, writer, csv_info_writer)

# Usage:

root_folder = input('source 경로를 입력해주세요 >> ')
if not os.path.exists(os.path.join(root_folder, 'output')):
    os.makedirs(os.path.join(root_folder, 'output'))
output_csv = os.path.join(root_folder, "output", "output.csv")

extract_information_and_save_to_csv(root_folder, output_csv)